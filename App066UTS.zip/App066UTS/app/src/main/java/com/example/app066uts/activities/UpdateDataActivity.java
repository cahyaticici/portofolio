package com.example.app066uts.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.app066uts.helper.DataHelper;
import com.example.app066uts.R;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

public class UpdateDataActivity extends AppCompatActivity {

    protected Cursor cursor;
    DataHelper dataHelper;
    ExtendedFloatingActionButton fabUpdate;
    EditText nomor, nama, tempatLahir, tanggalLahir, alamat;
    RadioButton jk;
    RadioGroup gender;
    SeekBar seekBarsm;
    TextView seekBarValue, spinnerValue;
    Spinner prodi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Update Data");
        setSupportActionBar(toolbar);
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dataHelper = new DataHelper(this);
        nomor = (EditText) findViewById(R.id.editText1);
        nama = (EditText) findViewById(R.id.editText2);
        tempatLahir = (EditText) findViewById(R.id.editText3);
        tanggalLahir = (EditText) findViewById(R.id.editText4);
        alamat = (EditText) findViewById(R.id.editText8);
        prodi = (Spinner) findViewById(R.id.prodi);

        gender = (RadioGroup) findViewById(R.id.jk);

        seekBarsm = (SeekBar) findViewById(R.id.seekBarsm);
        seekBarValue = (TextView) findViewById(R.id.viewsm);
        seekBarsm.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                    seekBarValue.setText(String.valueOf(progress + "Semester"));
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        prodi = (Spinner) findViewById(R.id.prodi);
        spinnerValue = (TextView) findViewById(R.id.viewPr);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.daftarProdi, android.R.layout.simple_spinner_dropdown_item);
        prodi.setAdapter(adapter);
        prodi.setOnItemSelectedListener(this);
        fabUpdate = findViewById(R.id.fabUpdate);
        submitRegis();
    }

    public void submitRegis() {
        int radioId = gender.getCheckedRadioButtonId();
        jk = (RadioButton) findViewById(radioId);


        SQLiteDatabase sqLiteDatabase = dataHelper.getReadableDatabase();
        cursor = sqLiteDatabase.rawQuery("SELECT * FROM data WHERE nama = '" +
                getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            nomor.setText(cursor.getString(0));
            nama.setText(cursor.getString(1));
            tempatLahir.setText(cursor.getString(2));
            tanggalLahir.setText(cursor.getString(3));
            jk.setText(cursor.getString(4));
            seekBarValue.setText(cursor.getString(5));
            prodi.setOnItemSelectedListener(cursor.getString(6));
            alamat.setText(cursor.getString(7));
        }
    }
        fabUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Log.d("create", "Data : " + nomor.getText().toString() + nama.getText().toString() + tempatLahir.getText().toString() + tanggalLahir.getText().toString() + jk.getText().toString() + seekBarValue.getText().toString() + spinnerValue.getText().toString() + alamat.getText().toString());
                SQLiteDatabase sqLiteDatabase = dataHelper.getWritableDatabase();
                sqLiteDatabase.execSQL("update data set nama='" +
                        nama.getText().toString() + "', tgl='" +
                        tempatLahir.getText().toString() + "', ttl='" +
                        tanggalLahir.getText().toString() + "', jk='" +
                        jk.getText().toString() + "', seekBarValue='" +
                        seekBarValue.getText().toString() + "', prodi='" +
                        prodi.getSelectedItem().toString() + "', seekBarValue='" +
                        alamat.getText().toString() + "' where no='" +
                        nomor.getText().toString() + "'");
                Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                MainActivity.mainActivity.RefreshList();
                finish();
            }
        });

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}