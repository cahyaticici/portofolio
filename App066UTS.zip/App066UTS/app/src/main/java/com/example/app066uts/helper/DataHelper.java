package com.example.app066uts.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Create by Cahyati_3311901066
 */

public class DataHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "datadiri.db";
    private static final int DATABASE_VERSION = 1;
    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE data(no INTEGER PRIMARY KEY, nama TEXT NULL, ttl TEXT NULL, tgl TEXT NULL, jk TEXT null, sm TEXT null, prodi TEXT null, alamat TEXT null);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);
        sql = "INSERT INTO data (no, nama, ttl, tgl, jk, sm, prodi, alamat) VALUES ('1', 'Cahyati','Manggar', '2001-08-03', 'Perempuan', '4', 'Teknik Informatika','Batam');";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {

    }
}